<?php

require_once( CD_PLUGIN_PATH . 'includes/frontend/ajax-order-total/order-total.php');
require_once( CD_PLUGIN_PATH . 'includes/frontend/thank-you/table-extend.php');
require_once( CD_PLUGIN_PATH . 'includes/frontend/checkout-fields.php');
require_once( CD_PLUGIN_PATH . 'includes/frontend/cod-options.php');