<?php 

// Add settings page to WooCommerce menu
add_action('admin_menu', 'accodps_wc_advance_payment_add_admin_menu');
function accodps_wc_advance_payment_add_admin_menu() {
    add_submenu_page('woocommerce', 'Advance Conditional COD Payment Settings', 'Advance Conditional COD Payment', 'manage_options', 'wc-advance-cod-payment-settings', 'accodps_wc_advance_payment_settings_page');
}

// Display settings page
function accodps_wc_advance_payment_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Advance Conditional COD Payment Settings', 'wc-advance-cod-payment'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('wc_advance_payment_settings');
            do_settings_sections('wc-advance-cod-payment-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'accodps_wc_advance_payment_settings_init');
function accodps_wc_advance_payment_settings_init() {
    register_setting('wc_advance_payment_settings', 'accodps_advance_payment_title', 'sanitize_text_field');
    register_setting('wc_advance_payment_settings', 'accodps_advance_payment_description', 'sanitize_text_field');
    register_setting('wc_advance_payment_settings', 'accodps_advance_payment_checkbox_text', 'sanitize_text_field');
    register_setting('wc_advance_payment_settings', 'wc_advance_payment_percentage', 'absint');
    register_setting('wc_advance_payment_settings', 'wc_advance_payment_min_order_total', 'absint');

    add_settings_section(
        'wc_advance_payment_settings_section',
        __('Advance Conditional COD Payment Settings', 'wc-advance-cod-payment'),
        '',
        'wc-advance-cod-payment-settings'
    );

    add_settings_field(
        'accodps_advance_payment_title',
        __('Title', 'wc-advance-cod-payment'),
        'accodps_advance_payment_title_render',
        'wc-advance-cod-payment-settings',
        'wc_advance_payment_settings_section'
    );

    add_settings_field(
        'accodps_advance_payment_description',
        __('Description', 'wc-advance-cod-payment'),
        'accodps_advance_payment_description_render',
        'wc-advance-cod-payment-settings',
        'wc_advance_payment_settings_section'
    );

    add_settings_field(
        'accodps_advance_payment_checkbox_text',
        __('Checkbox Text', 'wc-advance-cod-payment'),
        'accodps_advance_payment_checkbox_text_render',
        'wc-advance-cod-payment-settings',
        'wc_advance_payment_settings_section'
    );

    add_settings_field(
        'wc_advance_payment_percentage',
        __('Advance Payment Percentage', 'wc-advance-cod-payment'),
        'accodps_wc_advance_payment_percentage_render',
        'wc-advance-cod-payment-settings',
        'wc_advance_payment_settings_section'
    );

    add_settings_field(
        'wc_advance_payment_min_order_total',
        __('Minimum Order Total for Advance Payment', 'wc-advance-cod-payment'),
        'accodps_wc_advance_payment_min_order_total_render',
        'wc-advance-cod-payment-settings',
        'wc_advance_payment_settings_section'
    );
}

function accodps_wc_advance_payment_percentage_render() {
    global $adv_pay_per;
    echo '<input type="number" name="wc_advance_payment_percentage" value="' . esc_attr($adv_pay_per) . '" min="1" max="100" />';
}

function accodps_wc_advance_payment_min_order_total_render() {
    global $adv_min_order_total;
    echo '<input type="number" name="wc_advance_payment_min_order_total" value="' . esc_attr($adv_min_order_total) . '" min="0" />';
}

function accodps_advance_payment_title_render() {
    global $ap_title;
    echo '<textarea name="accodps_advance_payment_title" rows="5" cols="50">' . esc_textarea($ap_title) . '</textarea>';
}

function accodps_advance_payment_checkbox_text_render() {
    global $ap_checkbox_text;
    echo '<textarea name="accodps_advance_payment_checkbox_text" rows="5" cols="50">' . esc_textarea($ap_checkbox_text) . '</textarea>';
}

function accodps_advance_payment_description_render() {
    global $ap_description;
    echo '<textarea name="accodps_advance_payment_description" rows="5" cols="50">' . esc_textarea($ap_description) . '</textarea>';
}